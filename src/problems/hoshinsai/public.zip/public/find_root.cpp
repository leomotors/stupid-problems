#include "find_root.h"
#include <functional>

int find_root(std::function<double(double)> f) {
    // implement your function here
    return 0;
}
