#include <functional>

int find_root(std::function<double(double)> f);
